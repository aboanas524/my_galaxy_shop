import 'package:flutter/material.dart';
// import 'package:http/http.dart'as http;
// import 'dart:convert';

class Api {
  //   String url = Uri.https('http://localhost:8000','/api/product/all',{'q': '{http}'});
  //   Future getData()async{
  //   http.Response res = await http.get(url);
  //   if(res.statusCode==200)
  //     {
  //       var obj = json.decode(res.body);
  //       print(obj[0]['title']);
  //     }
  //     else
  //     {
  //       print('StateCode = ${res.statusCode}');
  //     }
  // }
  //







}